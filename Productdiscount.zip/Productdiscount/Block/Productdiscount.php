<?php
namespace Solwin\Productdiscount\Block;

Class Productdiscount extends \Magento\Framework\View\Element\Template{
	protected $productdiscountFactory;
	protected $customerSession;
	public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
		\Magento\Customer\Model\Session $customerSession,
		\Solwin\Productdiscount\Model\ResourceModel\Productdiscount\CollectionFactory $productdiscountFactory,
        array $data = []
    ) {
		$this->productdiscountFactory = $productdiscountFactory;
        parent::__construct($context, $data);
		$this->customerSession = $customerSession;
    }
	
	public function rewardpointCollection(){
		$customerid = $this->getCustomerId();
		$collection = $this->productdiscountFactory->create()->addFieldToFilter('customerid',$customerid)->addFieldToFilter('status','active');
		return $collection;
	}
    public function isCustomerLoggedIn()
	{
		return $this->_session->isLoggedIn();
	}
	public function getCustomerId(){
		return $this->customerSession->getCustomer()->getId();
	}
}