<?php

namespace Solwin\Productdiscount\Model;
 
class Productdiscount extends \Magento\Framework\Model\AbstractModel
{
   
    const CACHE_TAG = 'solwin_rewardpoint_record';
 
    protected $_cacheTag = 'solwin_rewardpoint_record';
 
    protected $_eventPrefix = 'solwin_rewardpoint_record';
 
    protected function _construct()
    {
        $this->_init('Solwin\Productdiscount\Model\ResourceModel\Productdiscount');
    }
}