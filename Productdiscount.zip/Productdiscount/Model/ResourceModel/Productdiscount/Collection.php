<?php
 
namespace Solwin\Productdiscount\Model\ResourceModel\Productdiscount;
 
class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    /**
     * @var string
     */
    protected $_idFieldName = 'rewardpoint_id';
    /**
     * Define resource model.
     */
    protected function _construct()
    {
        $this->_init('Solwin\Productdiscount\Model\Productdiscount', 'Solwin\Productdiscount\Model\ResourceModel\Productdiscount');
    }
}
