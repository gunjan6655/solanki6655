<?php
namespace Solwin\Productdiscount\Model\Quote;

class Discount extends \Magento\Quote\Model\Quote\Address\Total\AbstractTotal
{
	protected $customerSession;
	protected $productdiscountFactory;
	public function __construct(
		 \Magento\Framework\Event\ManagerInterface $eventManager,
		 \Magento\Store\Model\StoreManagerInterface $storeManager,
		 \Magento\SalesRule\Model\Validator $validator,
		 \Magento\Customer\Model\Session $customerSession,
		 \Magento\Framework\Pricing\PriceCurrencyInterface $priceCurrency,
		 \Magento\Framework\ObjectManagerInterface $objectmanager,
		 \Solwin\Productdiscount\Model\ResourceModel\Productdiscount\CollectionFactory $productdiscountFactory
	 ){
		 $this->setCode('testdiscount');
		 $this->eventManager = $eventManager;
		 $this->calculator = $validator;
		 $this->storeManager = $storeManager;
		 $this->customerSession = $customerSession;
		 $this->priceCurrency = $priceCurrency;
		 $this->_objectManager = $objectmanager;
		 $this->productdiscountFactory = $productdiscountFactory;
	}
	 
	public function collect(
        \Magento\Quote\Model\Quote $quote,
        \Magento\Quote\Api\Data\ShippingAssignmentInterface $shippingAssignment,
        \Magento\Quote\Model\Quote\Address\Total $total
    ) {
        parent::collect($quote, $shippingAssignment, $total);
		$customerSession = $this->customerSession->isLoggedIn();
		$customerid = $this->customerSession->getCustomer()->getId();
		$enable = $this->_objectManager->get('Magento\Framework\App\Config\ScopeConfigInterface')->getValue('productdiscount_section/general/enable');
		$rewardcollections = $this->productdiscountFactory->create()->addFieldToFilter('customerid',$customerid)->addFieldToFilter('status','active');
		$reward = count($rewardcollections);
		if($customerSession && $enable=1 && $reward!=0){
			$rewardpointvalue = array();
			foreach($rewardcollections as $rewardcollection){
				$rewardpointvalue[] = $rewardcollection->getRewardpointvalue();
			}
			$rewardpointvalue = array_sum($rewardpointvalue);
			//$items = $quote->getItemsCollection();
			//$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
			$onerewardpoint = $this->_objectManager->get('Magento\Framework\App\Config\ScopeConfigInterface')->getValue('productdiscount_section/rewardpointformfield/onerewardpoint');
			$rewardpointvalue = $rewardpointvalue*$onerewardpoint;
			//$rewardpointvalue = array();
			/*foreach($items as $item) {
				$product_id = $item->getProductId();
				$qty = $item->getQty();
				$sku = $item->getSku();
				$product = $objectManager->get('Magento\Catalog\Model\Product')->load($product_id);
				$rewardpointvaluefi = $product->getRewardpoint();	
				//$rewardpointvaluese = $rewardpointvaluefi*$onerewardpoint;
				$rewardpointvalue[] = $rewardpointvaluefi*$qty;
			}
			$rewardpointvalue = array_sum($rewardpointvalue);*/
			$label               = 'My Reward Point Discount';
			$discountAmount      = '-'.$rewardpointvalue;   
			$appliedCartDiscount = 0;
			if($total->getDiscountDescription()) {
				$appliedCartDiscount = $total->getDiscountAmount();
				$discountAmount      = $total->getDiscountAmount()+$discountAmount;
				$label               = $total->getDiscountDescription().', '.$label;
			}    
			$total->setDiscountDescription($label);
			$total->setDiscountAmount($discountAmount);
			$total->setBaseDiscountAmount($discountAmount);
			$total->setSubtotalWithDiscount($total->getSubtotal() + $discountAmount);
			$total->setBaseSubtotalWithDiscount($total->getBaseSubtotal() + $discountAmount);

			if(isset($appliedCartDiscount)) {
				$total->addTotalAmount($this->getCode(), $discountAmount - $appliedCartDiscount);
				$total->addBaseTotalAmount($this->getCode(), $discountAmount - $appliedCartDiscount);
			} else {
				$total->addTotalAmount($this->getCode(), $discountAmount);
				$total->addBaseTotalAmount($this->getCode(), $discountAmount);
			}
			
			return $this;
		}
	}
}