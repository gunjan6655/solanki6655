<?php
namespace Solwin\Productdiscount\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\App\Request\DataPersistorInterface;
use Magento\Framework\App\ObjectManager;

class ProductdiscountOrderObserver implements \Magento\Framework\Event\ObserverInterface
{
	protected $_order;
	protected $productdiscountFactory;
    public function __construct(
        \Magento\Sales\Api\Data\OrderInterface $order,
		\Magento\Framework\ObjectManagerInterface $objectmanager,
		\Solwin\Productdiscount\Model\ResourceModel\Productdiscount\CollectionFactory $productdiscountFactory
    ) {
         $this->_order = $order;
		 $this->productdiscountFactory = $productdiscountFactory;
		 $this->_objectManager = $objectmanager;
    }
	
	public function execute(\Magento\Framework\Event\Observer $observer)
    {
		$orderids = $observer->getEvent()->getOrderIds();
		//$onerewardpoint = $this->_objectManager->get('Magento\Framework\App\Config\ScopeConfigInterface')->getValue('productdiscount_section/rewardpointformfield/onerewardpoint');
        foreach($orderids as $orderid){
            $order = $this->_order->load($orderid);
			$customer_id = $order->getCustomerId();
			$items = $order->getItemsCollection();
			$collections = $this->productdiscountFactory->create()->addFieldToFilter('customerid',$customer_id);
			//print_r($collections->getData());exit;
			$id = array();
			$collection = $this->_objectManager->get('Solwin\Productdiscount\Model\Productdiscount');
			foreach ($collections as $collection)
			{
				$id=$collection['rewardpoint_id'];
				$collection->load($id);
				$collection->setData('status','complate');
				$collection->save();
			}
			//print_r($id);exit;
			
			
			foreach($items as $item) {
				$product_id = $item->getProductId();
				$qty = $item->getQtyOrdered();
				$sku = $item->getSku();
				$product = $this->_objectManager->get('Magento\Catalog\Model\Product')->load($product_id);
				$rewardpointvaluefi = $product->getRewardpoint();
				$rewardpointvalue = $rewardpointvaluefi*$qty;
				$model = $this->_objectManager->create('Solwin\Productdiscount\Model\Productdiscount');
				$model->setData('productsku',$sku);
				$model->setData('customerid',$customer_id);
				$model->setData('rewardpointvalue',$rewardpointvalue);
				$model->setData('status','active');
				//$model->setData('status','pending');
				$model->save();
			}
        }
    }
}