<?php

namespace Solwin\Productdiscount\Controller\Adminhtml\Productdiscount;

class Delete extends \Magento\Backend\App\Action
{
    
    public function execute()
    {
       
        $resultRedirect = $this->resultRedirectFactory->create();
        // check if we know what should be deleted
        $id = $this->getRequest()->getParam('rewardpoint_id');
        if ($id) {
            try {
                // init model and delete
                $model = $this->_objectManager->create('Solwin\Productdiscount\Model\Productdiscount');
                $model->load($id);
                $model->delete();
                // display success message
                $this->messageManager->addSuccess(__('You deleted the item.'));
                // go to grid
                return $resultRedirect->setPath('*/*/');
            } catch (\Exception $e) {
                // display error message
                $this->messageManager->addError($e->getMessage());
                // go back to edit form
                
            }
        }
        // display error message
        $this->messageManager->addError(__('We can\'t find the item to delete.'));
        // go to grid
        return $resultRedirect->setPath('*/*/');
    }
}
